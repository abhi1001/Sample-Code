import React from 'react';
import { Table, Button, Alert } from 'react-bootstrap';
import './team.css'

class team extends React.Component {
    render(){
    return (
  
<div>

    
<div class="topnav">
                    <a href="/"><font color="black">Home</font></a>
                    <a href="/Hotel"><font color="black">Hotel</font></a>
                    <a href="/Vplace"><font color="black">Visiting Place</font></a>
                    <a   href="/contact"><font color="black">Contact</font></a>
                    <a  class="active" href="/team"><font color="black">Team Members</font></a>
                </div>
    <center><p1><b><font color="red">Team Members</font></b></p1></center>

    <div class="row111">
  <div class="column111">
    <div class="card123">
      <img class="ttt" src="./anamikadi.JPG" alt="Jane"/>
      <div class="container99">
      <h3><center>Anamika Chatterjee</center></h3>
      <p class="title"><center>Data Warehousing</center></p>
      <p> <center><b>Team Leader</b></center></p>
      <p><center>anamika_chatterjee@in.ibm.com</center></p>
      <p><center><button class="button99" ><a href="https://w3.ibm.com/bluepages/profile.html?uid=121822744" target="_blank"><b>Bluepage</b></a></button></center></p>
      </div>
    </div>
  </div>

  <div class="column111">
    <div class="card123">
      <img class="ttt" src="./sayantan.png" alt="Mike" />
      <div class="container99">
      <h3><center>Sayantan Roy</center></h3>
      <p class="title"><center>Data Warehousing</center></p>
      <p> <center><b>Team Captain</b></center></p>
      <p><center>sayaroy3@in.ibm.com</center></p>
      <p><center><button class="button99" ><a href="https://w3.ibm.com/bluepages/profile.html?uid=00902V744" target="_blank"><b>Bluepage</b></a></button></center></p>
      </div>
    </div>
  </div>
  
  <div class="column111">
    <div class="card123">
      <img class="ttt" src="./Amit3.jpg" alt="John" />
      <div class="container99">
      <h3><center>Amit Singh</center></h3>
      <p class="title"><center>Application Developer - RPA</center></p>
      <p> <center><b>Team Member</b></center></p>
      <p><center>amits121@in.ibm.com</center></p>
      <p><center><button class="button99" ><a href="https://w3.ibm.com/bluepages/profile.html?uid=000GRQ744" target="_blank"><b>Bluepage</b></a></button></center></p>
      </div>
    </div>
  </div>

  <div class="column111">
    <div class="card123">
      <img class="ttt" src="./hara.png" alt="John" />
      <div class="container99">
      <h3><center>Hara Jena</center></h3>
      <p class="title"><center>Application Developer - RPA</center></p>
      <p> <center><b>Team Member</b></center></p>
      <p><center>harajena@in.ibm.com</center></p>
      <p><center><button class="button99" ><a href="https://w3.ibm.com/bluepages/profile.html?uid=09574J744" target="_blank"><b>Bluepage</b></a></button></center></p>
      </div>
    </div>
  </div>
  <div class="column111">
    <div class="card123">
      <img class="ttt" src="./siri.jpeg" alt="John"/>
      <div class="container99">
      <h3><center>Siri chandana</center></h3>
      <p class="title"><center>Application Developer - Devops</center></p>
      <p> <center><b>Team Member</b></center></p>
      <p><center>snandan1@in.ibm.com</center></p>
      <p><center><button class="button99" ><a href="https://w3.ibm.com/bluepages/profile.html?uid=0004O8744" target="_blank"><b>Bluepage</b></a></button></center></p>
      </div>
    </div>
  </div>

  <div class="column111">
    <div class="card123">
      <img class="ttt" src="./Abhishek.jpg" alt="John"/>
      <div class="container99">
      <h3><center>Abhishek Agarwal</center></h3>
      <p class="title"><center>Data Engineer</center></p>
      <p> <center><b>Team Member</b></center></p>
      <p><center>abagra17@in.ibm.com</center></p>
      <p><center><button class="button99" ><a href="https://w3.ibm.com/bluepages/profile.html?uid=000GJB744" target="_blank"><b>Bluepage</b></a></button></center></p>
      </div>
    </div>
  </div>
</div>



   
</div>

    );
}
}
export default team;